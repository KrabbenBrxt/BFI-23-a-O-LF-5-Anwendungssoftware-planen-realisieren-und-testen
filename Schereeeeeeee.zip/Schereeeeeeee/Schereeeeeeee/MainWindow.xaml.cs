﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Schereeeeeeee
{
    public partial class MainWindow : Window
    {
        Random random = new Random();
        int RandomNumber;
        int counter = 0;
        public MainWindow()
        {
            InitializeComponent();
        }
        
       
        public void RANDOMZAHL()
        {
            
            RandomNumber = random.Next(0, 3);
            if (RandomNumber == 0) 
            {
                COM.Source = new BitmapImage(new Uri("img/Paper.png", UriKind.Relative));
            }
            if(RandomNumber == 1) 
            {
                COM.Source = new BitmapImage(new Uri("img/Stone.png", UriKind.Relative));
            }
            if (RandomNumber == 2) 
            {
                COM.Source = new BitmapImage(new Uri("img/Schere1.png", UriKind.Relative));
            }


        }
       
        private void Clickpaper(object sender, MouseButtonEventArgs e)
        {
            Coolesbild.Source = new BitmapImage(new Uri("img/Paper.png", UriKind.Relative));   
            RANDOMZAHL();
            Spieler.Content = ("Du wählst:");
            counter++;
            COM1.Content = ("COM wählt:");

            switch (RandomNumber)
            {
                case 0:
                    {
                        Ergebnis.Content = ("Unentschieden");
                    }
                    break;
                case 1:
                    {
                        Ergebnis.Content = ("Du hast Gewonnen");
                    }
                    break;
                case 2:
                    {
                        Ergebnis.Content = ("COM hat Gewonnen");
                    }
                    break;
                }
            Counter1.Content = counter;

        }

        private void Click_Schere(object sender, MouseButtonEventArgs e)
        {
            Coolesbild.Source = new BitmapImage(new Uri("img/Schere1.png", UriKind.Relative));
            RANDOMZAHL();
            Spieler.Content = ("Du wählst:");
            COM1.Content = ("COM wählt:");
            counter++;
            switch (RandomNumber)
            {
                case 0:
                    {
                        Ergebnis.Content = ("Du hast Gewonnen");
                    }
                    break;
                case 1:
                    {
                        Ergebnis.Content = ("COM hat Gewonnen");
                    }
                    break;
                case 2:
                    {
                        Ergebnis.Content = ("Unentschieden");
                    }
                    break;
            }
            Counter1.Content = counter;
        }

        private void Click_Stein(object sender, MouseButtonEventArgs e)
        {
            Coolesbild.Source = new BitmapImage(new Uri("img/Stone.png", UriKind.Relative));
            RANDOMZAHL();
            Spieler.Content = ("Du wählst:");
            counter++;
            COM1.Content = ("COM wählt:");

            switch (RandomNumber)
            {
                case 0:
                    {
                        Ergebnis.Content = ("COM hat Gewonnen");
                    }
                    break;
                case 1:
                    {
                        
                        Ergebnis.Content = ("Unentschieden");
                    }
                    break;
                case 2:
                    {
                        Ergebnis.Content = ("Du hast Gewonnen");
                    }
                    break;
            }
            Counter1.Content = counter;
        }
        
   
    }
}
