﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM_Haustiere
{
    internal class Schlange : Haustier
    {
        public bool Giftig { get; protected set; }

        public Schlange(double gewicht, string name, string rasse, bool giftig) : base(gewicht,name , rasse)
        {
            Giftig = giftig;
        }

    }
}
