﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM_Haustiere
{
    internal class Katze : Haustier
    {
        public int Uebrigeleben { get; protected set; }

        public Katze(double gewicht,string name,string rasse, int uebrigeleben) : base(gewicht, rasse, name)
        {
            Uebrigeleben = uebrigeleben;
        }

        public override string ToString()
        {
            return $"Die Katze {base.ToString()} Sie hat noch {Uebrigeleben} Leben.";
        }
    }
}
