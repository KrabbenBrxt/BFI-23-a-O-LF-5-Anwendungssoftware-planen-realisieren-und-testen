﻿using PM_Haustiere;
Katze k = new Katze(5, "Maya", "Kurzhaar", 9);

Schlange s = new Schlange(7,"Cobra","Alvin",true);

k.Klettern();

s.Beißen();