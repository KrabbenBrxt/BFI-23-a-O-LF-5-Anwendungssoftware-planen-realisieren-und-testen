﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM_Haustiere
{
    internal class Haustier
    {
        public Haustier() { }
        public double gewicht {set; protected get; }
        public string rasse { set; protected get; }
        public string name { set; protected get; }

        public Haustier(double gewicht, string rasse, string name)
        {
            this.gewicht = gewicht;
            this.rasse = rasse;
            this.name = name;
        }
        
        public void Klettern()
        {
            Console.WriteLine($"Haustier {name} klettert.");
        }

        public void Schlafen(double stunden) 
        {
            Console.WriteLine($"Haustier{name} schläft für {stunden}h.");
        }
       
        public void Fressen()
        {
            Console.WriteLine($"Haustier{name} frisst.");
        }

        public void Beißen()
        {
            Console.WriteLine($"Haustier {name} beißt djabrail");
        }

        public override string ToString() 
        {
            return $"{name} wiegt {gewicht} und hat die Rasse {rasse}";
        }
    }
}
