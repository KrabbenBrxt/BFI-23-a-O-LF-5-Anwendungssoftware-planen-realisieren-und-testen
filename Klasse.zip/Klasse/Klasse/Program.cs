﻿
using Klasse;

Magier m1 = new Magier();
Magier m2 = new Magier();
Magier m3 = new Magier();

m1.Name = "Eren Yeager";
m2.Name = "Mikasa Ackerman";
m3.Name = "Armin Alert";

m1.Gas = 50;
m2.Gas = 78;
m3.Gas = 92;

m1.Zauber.Add("3d Manöver");
m2.Zauber.Add("3d Manöver");
m3.Zauber.Add("3d Manöver");
m1.Zauber.Add("Titan Verwandlung");
m1.Zauber.Add("Rumbling");

Console.WriteLine("1.3d Manöver");
Console.WriteLine("2.Titan verwandlung");

string fähigkeiten = Console.ReadLine();

    if (fähigkeiten == "1")
    {
        m1.Zaubern(0);
    }

    if (fähigkeiten == "2")
    {
        m1.Zaubern(1);
    }
   
