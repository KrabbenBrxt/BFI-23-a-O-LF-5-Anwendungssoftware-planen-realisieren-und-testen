﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Klasse
{
    internal class Magier
    {
        public string Name;
        public int Hp;
        public int Gas;
        public List<string> Zauber = new List<string>();

    
        public void Zaubern(int i)
        {
            if (Gas > 0)
            {
                Gas--;
                Console.WriteLine($"{Name} benutzt {Zauber[i]}.");
            }
            else
            {
                Console.WriteLine($"{Name} hat kein Gas mehr.");
            }
        }
    }
}
