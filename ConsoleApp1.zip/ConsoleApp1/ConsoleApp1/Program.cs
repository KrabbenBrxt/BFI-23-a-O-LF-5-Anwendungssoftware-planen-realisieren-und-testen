﻿using System;

namespace ConsoleApp
{
    internal class Waffe
    {
        public string Name { get; set; }
        public int BaseDmg { get; set; }
        public int MaxDmg { get; set; }
        private Random _rnd;

        public Waffe(string name, int baseDmg, int maxDmg, Random rnd)
        {
            Name = name;
            BaseDmg = baseDmg;
            MaxDmg = maxDmg;
            _rnd = rnd;
        }

        public int KampfschadenBerechnen()
        {
            return _rnd.Next(BaseDmg, MaxDmg + 1);
        }

        public override string ToString()
        {
            return $"{Name}, Dmg: {BaseDmg} - {MaxDmg}";
        }
    }

    internal class Krieger
    {
        public string Name { get; set; }
        public int Hp { get; set; }
        public int Rüstung { get; set; }
        public Waffe Waffe { get; set; }

        public Krieger(string name, int hp, int rüstung, Waffe waffe)
        {
            Name = name;
            Hp = hp;
            Rüstung = rüstung;
            Waffe = waffe;
        }

        public void Angriff(Magier gegner)
        {
            int schaden = Waffe.KampfschadenBerechnen();
            Console.WriteLine($"{Name} greift {gegner.Name} an und verursacht {schaden} Schaden!");
            gegner.Hp -= Math.Max(0, schaden - gegner.Rüstung);
            Console.WriteLine($"{gegner.Name} hat jetzt {gegner.Hp} HP!");
        }
    }

    internal class Magier
    {
        public string Name { get; set; }
        public int Hp { get; set; }
        public int Mp { get; set; }
        public int Rüstung { get; set; }
        public Waffe Waffe { get; set; }

        public Magier(string name, int hp, int mp, int rüstung, Waffe waffe)
        {
            Name = name;
            Hp = hp;
            Mp = mp;
            Rüstung = rüstung;
            Waffe = waffe;
        }

        public override string ToString()
        {
            return $"{Name}, {Hp} HP | {Mp} MP | {Rüstung} AMR mit der Waffe {Waffe.ToString()}";
        }

        public int Feuerball(int i)
        {
            if (Mp >= 10)
            {
                Mp -= 10; 
                int schaden = 15 + i;
                Console.WriteLine($"{Name} zaubert Feuerball und verursacht {schaden} Schaden!");
                return schaden;
            }
            else
            {
                Console.WriteLine($"{Name} hat nicht genügend MP für Feuerball!");
                return 0;
            }
        }

        public void Angriff(Krieger gegner)
        {
            int schaden = Waffe.KampfschadenBerechnen();
            Console.WriteLine($"{Name} greift {gegner.Name} an und verursacht {schaden} Schaden!");
            gegner.Hp -= Math.Max(0, schaden - gegner.Rüstung); 
            Console.WriteLine($"{gegner.Name} hat jetzt {gegner.Hp} HP!");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();

            Krieger k = new Krieger("Herbert, der Schreckliche", 129, 10, new Waffe("Excalibur", 9, 12, random));
            Magier m = new Magier("Gönndalf, der Blaue", 120, 6, 2, new Waffe("Elder Wand", 9, 12, random));

            while (k.Hp > 0 && m.Hp > 0)
            {
               
                k.Angriff(m);
                if (m.Hp <= 0) break;

                
                m.Angriff(k);
            }

            Console.WriteLine();

            if (k.Hp > 0)
            {
                Console.WriteLine($"{k.Name} hat gesiegt. {m.Name} in einer epischen Schlacht gefallen.");
            }
            else if (m.Hp > 0)
            {
                Console.WriteLine($"{m.Name} hat gesiegt. {k.Name} in einer epischen Schlacht gefallen.");
            }
            else
            {
                Console.WriteLine($"{m.Name} und {k.Name} sind beide in einer epischen Schlacht gefallen.");
            }
        }
    }
}
