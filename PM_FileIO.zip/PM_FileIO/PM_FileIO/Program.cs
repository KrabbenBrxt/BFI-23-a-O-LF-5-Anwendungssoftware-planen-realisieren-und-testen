﻿
try
{
    Console.WriteLine("Geben sie den Daeteinamen ein");
    string dateiname = Console.ReadLine();

    if (!File.Exists(dateiname))
    {
        Console.WriteLine("Datei exestiert nicht !!");
      
    }
    Console.WriteLine("\n Ihnhalt der Datei");
    using (StreamReader reader = new StreamReader(dateiname))
    {
        string zeile;
        while ((zeile = reader.ReadLine()) != null)
        {
            Console.WriteLine(zeile);
        }
    }

    string copyDateiName = "copy.txt";
    using (StreamReader reader = new StreamReader(dateiname))
    using (StreamReader writer = new StreamReader(copyDateiName))
    {
        string zeile;
        while ((zeile = reader.ReadLine()) != null)
        {
           Console.WriteLine(zeile);
        }
        
    }


    Console.WriteLine($"\nDie Datei '{copyDateiName}' wurde erfolgreich erstellt.");
}
    
 
    catch (FileNotFoundException ex)
    {   
        Console.WriteLine("Fehler: Datei wurde nicht gefunden.");
    }
    catch (UnauthorizedAccessException ex)
    {
        Console.WriteLine("Fehler: Kein Zugriff auf die Datei.");
    }
    catch (IOException ex)
    {
        Console.WriteLine("Ein Fehler ist beim Lesen oder Schreiben aufgetreten: " + ex.Message);
    }
    catch (Exception ex)
    {
        Console.WriteLine("Ein unerwarteter Fehler ist aufgetreten: " + ex.Message);
    }
