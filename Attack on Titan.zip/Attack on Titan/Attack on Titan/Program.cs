﻿using Attack_on_Titan;

List<string> Fähigkeiten = new List<string>();

Fähigkeiten.Add("3d Manöver");
Fähigkeiten.Add("Titan-Kräfte");

Eren_Yeager m1 = new Eren_Yeager("Eren Yeager",100, 68, 46);

m1.Fähigkeiten(0);
