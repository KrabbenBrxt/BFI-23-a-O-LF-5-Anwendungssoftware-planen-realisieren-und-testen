﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Attack_on_Titan
{
    internal class Eren_Yeager
    {
        public string Name;
        public int Leben;
        public int Ausdauer;
        public int Gas;
        public List<string> Fähigkeiten = new List<string>();

        public Eren_Yeager(string name, int leben, int ausdauer, int gas, List<string> fähigkeiten)
        {
            Name = name;
            Leben = leben;
            Ausdauer = ausdauer;
            Gas = gas;
            Fähigkeiten = fähigkeiten;
        }

        public void Fähigkeiten_use(int i)
        {
            if(Ausdauer > 20 && Gas > 1) 
            {
                Ausdauer--;
                Console.WriteLine($"{Name} benutzt {Fähigkeiten[i]}");
            }
        }
        

    }
}
