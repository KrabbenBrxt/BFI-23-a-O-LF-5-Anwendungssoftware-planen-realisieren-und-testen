﻿using ClassLibrary;

Auto a = new Auto("VW", "Golf", 1998, 75, 50, 6.5);

bool running = true;
while (running)
{
    try
    {
        Console.WriteLine("\n\n----------------------------------------------\n\n");
        Console.WriteLine(a);
        Console.WriteLine("\nWas wollen Sie tun?");
        Console.Write("1: Fahren\t2: Tanken\t3: Reichweite anzeigen\t\t0: Beenden\t");
        int eingabe = Convert.ToInt32(Console.ReadLine());
        Console.Clear();

        switch (eingabe)
        {
            case 0:
                running = false;
                break;
            case 1:
                Console.Write("Wie weit wollen Sie fahren? ");
                double fahren = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine($"Es wurden {a.Fahren(fahren):f2} km gefahren.");
                break;
            case 2:
                Console.Write("Wie viel wollen Sie tanken? ");
                double tanken = Convert.ToDouble(Console.ReadLine());
                double getankt = a.Tanken(tanken);
                double preis = 1.69;
                Console.WriteLine($"Es wurden {getankt:f2} l getankt. Das macht {(getankt * preis):f2} Euro bei {preis} Euro pro Liter.");
                break;
            case 3:
                Console.WriteLine($"Es können noch {a.RestKmBerechnen():f2} km gefahren werden.");
                break;
            default:
                Console.WriteLine("Eingabe unbekannt.");
                break;
        }

    }
    catch (Exception e)
    {
        Console.WriteLine($"Bei der Eingabe ist wohl etwas schief gelaufen: {e.Message}");
    }
}