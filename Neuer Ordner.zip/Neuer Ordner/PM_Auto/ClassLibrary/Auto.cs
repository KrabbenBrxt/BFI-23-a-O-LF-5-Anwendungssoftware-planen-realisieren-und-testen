﻿
namespace ClassLibrary
{
    public class Auto
    {
        public string Hersteller { get; private set; }
        public string Modell { get; private set; }
        public int Baujahr { get; private set; }
        public double Leistung { get; private set; }
        public double TankMax { get; private set; }
        public double TankAktuell { get; private set; }
        public double Verbrauch { get; private set; }
        public double Km { get; private set; }

        public Auto()
        {
            Hersteller = "NoName";
            Modell = "NoModel";
            Baujahr = 0;
            Leistung = 0.0;
            TankMax = 0.0;
            TankAktuell = TankMax;
            Verbrauch = 0.0;
            Km = 0.0;
        }

        public Auto(string hersteller, string modell, int baujahr, double leistung, double tankMax, double verbrauch)
        {
            Hersteller = hersteller;
            Modell = modell;
            Baujahr = baujahr;
            Leistung = leistung;
            TankMax = tankMax;
            TankAktuell = tankMax;
            Verbrauch = verbrauch;
            Km = 0.0;
        }

        public double Fahren(double km)
        {
            double gefahren = km;

            if (km > RestKmBerechnen())
            {
                gefahren = RestKmBerechnen();
            }

            TankAktuell -= gefahren * (Verbrauch / 100);

            // Km = Km + gefahren;
            Km += gefahren;

            return gefahren;
        }

        public double Tanken(double liter)
        {

            if (liter <= 0) return 0.0;

            TankAktuell += liter;

            double zuViel = 0;

            if (TankMax < TankAktuell)
            {
                zuViel = TankAktuell - TankMax;
                TankAktuell = TankMax;
            }

            return liter - zuViel;
        }

        public double RestKmBerechnen()
        {

            return (TankAktuell / Verbrauch) * 100;

        }

        public override string ToString()
        {
            return $"{Hersteller} {Modell} ({Baujahr}) mit {Leistung}PS | {Km}km | Tank: {TankAktuell}/{TankMax}l | V: {Verbrauch}/100km";
        }
    }
}